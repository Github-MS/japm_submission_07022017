#####################################
#                                   #
# Graphs for JAPM manuscript (APA6) #
#                                   #
#####################################

# JAPM ITEM BIAS DOTPLOTS (FIGURE 1)   ----------------------------------------------

png("C:/JAPM/Graphs/FIGURE_1_ITEMMEDIANBIAS.PNG",
    width=960,height=1280)

par(mfrow=c(4,2),
    mai=c(0.3,0.6,0.1,0.1))

# assign in order ggum, ghcm and parella value to the color and shape of points
# assign order of person distribution

color.set <- box.set1 <- c("grey70","grey50","grey30")

beta.label  <- c(paste("REGULARLY","\n", "DISTRIBUTED","\n", "ITEMS"),
                 paste("IRREGULARLY","\n", "DISTRIBUTED","\n", "ITEMS"))

theta.label <- c("Normal",
                 "Bimodal",
                 "Skewed",
                 "Uniform")   

point.set <- c(21,22,23)

# Outer cycles for rotate through plots in 4 by 2 frame 

for (thetas in 1:4) {      # switch between distributions
  
  for (betas in 1:2) {     # switch between even grid and uniform grid
    
    # start the plot as empty
    
    options(warn=-1) # suppress warning of empty plot
    
    plot("n",
         main="",
         xlab="", ylab="",
         xlim=c(1,20),
         ylim=c(-3,+3),
         xaxp=c(1,20,19),
         yaxp=c(-3,+3,12),
         las=1); 
    
    options(warn=0) # restore warnings for debugging
    
    # select legends appearance for top diagrams
    
    if (thetas == 1) {
      
      if (betas == 1) {
        
        legend("bottomright",
               legend=c("Circle:   GGUM",
                        "Square: GHCM",
                        "Diamond: PARELLA"), 
               bty = "n",
               cex = 2)
        
      }
      
      legend("top", 
             legend=beta.label[betas], 
             xjust = 0.5,
             bty = "n",
             cex = 2)
      
    }
    
    if (betas == 1) {legend("topleft",
                            legend=paste(theta.label[thetas],
                                         "\n","Person",
                                         "\n","Distribution",
                                         sep=""), 
                            bty = "n",
                            cex = 2)}
    
    
    abline(h=seq(-3,+3,length.out=13),v=1:20,
           lty=3,col="grey")
    
    abline(h=0,lty=2,col="black")
    
    
    # start inner cycle to rotate through models and items
    
    for (models in 1:3) {    # switch between models
      
      for (items in 1:20) {   # switch between items estimates
        
        # Arrows to provide empirical CI90 5%, 95%
        
        Lower.Bound <- Item.Quant05.Bias.Vector.japm[[items]][betas,thetas,models]
        
        Upper.Bound <- Item.Quant95.Bias.Vector.japm[[items]][betas,thetas,models]
        
        arrows(x0 = items,
               y0 = Lower.Bound,
               y1 = Upper.Bound,
               length = 0.05,
               angle = 90,
               code = 3,
               col = box.set1[models])
        
        # points will upload from list of arrays
        
        points(x = items,
               y = Item.Median.Bias.Vector.japm[[items]][betas,thetas,models],
               cex = 2.25,
               pch = point.set[models],
               bg  = color.set[models])
        
      } # end item cycle 
      
    }  # end models cycle
    
  }    # end plot colum cycle
  
}      # end plot row cycle

dev.off()

# JAPM ITEM SIGMA2 DOTPLOTS (FIGURE 2) ----------------------------------------------

png("C:/JAPM/Graphs/FIGURE_2_ITEMVARIANCE.PNG",
    width = 960, height = 1280)

par(mfrow=c(4,2),
    mai=c(0.3,0.4,0.1,0.1))

# assign in order ggum, ghcm and parella value to the color and shape of points
# assign order of person distribution

color.set <- box.set1 <- c("grey70","grey50","grey30")

beta.label  <- c(paste("REGULARLY","\n", "DISTRIBUTED","\n", "ITEMS"),
                 paste("IRREGULARLY","\n", "DISTRIBUTED","\n", "ITEMS"))

theta.label <- c("Normal",
                 "Bimodal",
                 "Skewed",
                 "Uniform")   

point.set <- c(21,22,23)

# Outer cycles for rotate through plots in 4 by 2 frame 

for (thetas in 1:4) {      # switch between distributions
  
  for (betas in 1:2) {     # switch between even grid and uniform grid
    
    # start the plot as empty
    
    options(warn=-1) # suppress warning of empty plot
    
    plot("n",
         main="",
         xlab="", ylab="",
         xlim=c(1,20),
         ylim=c(0,+0.5),
         xaxp=c(1,20,19),
         yaxp=c(0,0.5,10),
         las=1); 
    
    options(warn=0) # restore warnings for debugging
    
    # select legends appearnce for top diagrams
    
    if (thetas == 1) {
      
      if (betas == 1) {
        
        legend("topleft",
               legend=c("Circle:   GGUM",
                        "Square: GHCM",
                        "Diamond: PARELLA"), 
               bty = "n",
               cex = 2)
        
      }
      
      legend("topright",
             legend=beta.label[betas],
             xjust = 1,
             bty = "n",
             cex = 2)
      
    }
    
    if (betas == 1) {legend("left",
                            legend=paste(theta.label[thetas],"Person Distribution"), 
                            bty = "n",
                            cex = 2)}
    
    
    abline(h=seq(0,+0.5,length.out=11),v=1:20,
           lty=3,col="grey")
    
    abline(h=0,lty=2,col="black")
    
    # start inner cycle to rotate through models and items
    
    for (models in 1:3) {    # switch between models
      
      for (items in 1:20) {   # switch between items estimates
        
        # points will upload from list of arrays    
        
        points(x = items,
               y = Item.Mean.Sigma2.Vector.japm[[items]][betas,thetas,models],
               cex = 2.25,
               pch = point.set[models],
               bg  = color.set[models])
        
      } # end item cycle 
      
    }  # end models cycle
    
  }    # end plot colum cycle
  
}      # end plot row cycle

dev.off()

################################################

# JAPM KL AND PERSON RECOVERY (FIGURE 3) ---------------------------------------------------

png("C:/JAPM/Graphs/FIGURE_4_KL_PERSONRECOVERY.PNG",
    width=960,height=1280)

par(mfrow=c(4,2),
    cex.axis = 1.25,
    cex.lab  = 1.5,
    mai=c(0.4,0.8,0.1,0.1))

# Nature of lines for models and quantiles curves

color.set <- box.set1 <- c("grey70","grey50","grey30")

quantile.lines <- c(3,1,3) 

quantile.thickness <- c(1,2,1)

# CYCLE THROUGH THETA DISTRIBUTIONS

for (thetas in 1:4) {
  
  #####################
  #                   #
  # Get boxplot of KL #
  #                   #
  #####################  
  
  boxplot(KL~MODEL,
          data = Recovery.Theta.japm[Recovery.Theta.japm$THETA==theta.label[thetas],],
          main = "",
          ylab = "KULLBACK-LEIBLER",
          yaxp = c(0,2.5,10),
          ylim = c(0,2.5),
          col = color.set,
          border = box.set1,
          horizontal = FALSE); grid(nx=NA,ny=NULL,col="darkgrey")
  
  legend("topright",
         legend=theta.label[thetas], 
         bty = "n",
         cex = 2)
  
  if (thetas==1) {
    
    legend("topleft",
           legend=c("GGUM:        Light Gray",
                    "GHCM:        Medium Gray",
                    "PARELLA:   Darker Gray",
                    "Simulation: Black"), 
           bty = "n",
           cex = 1.5)
    
  }
  
  abline(h=seq(0,2.5,length.out=11),lty=3,col="grey")  
  
  abline(h=0,lty=2,col="black")
  
  ################
  #              #
  # Get KDE plot #
  #              #
  ################
  
  options(warn=-1) # suppress warnings for empty plot
  
  plot("n",
       main="",
       xlab="", 
       ylab="DENSITY",
       xlim=c(-6,+6),
       ylim=c(0,+1),
       xaxp=c(-6,+6,12),
       las=1); 
  
  options(warn=0) # restore warnings for debugging
  
  grid()
  
  # display conditional explanation of curves
  
  if (thetas==1) {
    
    text(0,0.8,
         paste("GGUM, GHCM PARELLA Curves are","\n",
               "the 5%, 50%, 95% quantiles of KDE","\n",
               "of Model Person Location Estimates",
               sep=""),
         pos = 1,
         cex = 1.5)  
  
  }
  
  # display the type of distribution

  legend("topright",
         legend=theta.label[thetas], 
         bty = "n",
         cex = 2)
  
  abline(v=seq(-8,+8,length.out = 17),
         lty=3,col="gray")
  
  abline(v=0,lty=2,col="black")
  
  for (models in 1:3) {
    
    # cycle through simulation (200 obs blocks)
    
    selection <- (as.numeric(Recovery.Theta.japm[,4])==models & as.numeric(Recovery.Theta.japm[,3])==thetas)
    
    selected  <- Recovery.Theta.japm[selection,5:1008]
    
    density.grid <- as.numeric(density(as.numeric(selected[1,]),
                                       from = -6,
                                       to = +6,
                                       na.rm=TRUE)$x) # sufficient to consider the first row - match KL estimation boundaries
    
    densities <- apply(selected,
                       1,
                       function(x) as.numeric(density(as.numeric(x),
                                                      from = -6,
                                                      to = +6,
                                                      na.rm=TRUE)$y))
    
    # now get 0.05, 0.50, 0.95 quantile matrix by running apply() on rows and
    # get matrix 3 X 512, with columns representing density quantiles across simulations
    
    quantiles.densities <- apply(densities,
                                 1,
                                 function(x) quantile(as.numeric(x),
                                                      probs = c(0.05,0.50,0.95),
                                                      na.rm=TRUE))
    
    # draw quantile lines by selecting different types of line
    
    for (quantile in 1:3) {
      
      # select data according to model and distribution and quantile of the KL values
      
      lines(density.grid, quantiles.densities[quantile,],
            lty = quantile.lines[quantile],
            lwd = quantile.thickness[quantile],
            col = color.set[models])
      
    } # end quantile loop
    
    selected <- densities <- quantiles.densities <- NULL; selection <- NULL # Clear up 
    
  }  # end model loop
  
  # build density of simulation data - as these are repeated across
  # simulations, selected only the first one of each simulation blocks
  # enact out of model loop to superimpose graph - adopt same density boundaries of recovered data
  
  lines(density(Benchmark.Theta.japm[(1+(100*(thetas-1))),4:1003],
                from = -6,
                to = +6,
                na.rm=TRUE), 
                lty=1, lwd=2) 
  
} # end distribution loop

dev.off()

#################################################

# JAPM DELTA P DOTPLOT (FIGURE 4) ----------------------------------------------

png("C:/JAPM/Graphs/FIGURE_4_ITEMDELTAP.PNG",
    width=960,height=1280)

par(mfrow=c(4,2),
    mai=c(0.4,0.7,0.1,0.1),
    cex.main = 2,
    cex.lab = 1.1,
    cex.axis = 1.1)

# assign in order ggum, ghcm and parella value to the color and shape of points
# assign order of person distribution

color.set <- box.set1 <- c("grey70","grey50","grey30")

beta.label  <- c(paste("REGULARLY","\n", "DISTRIBUTED","\n", "ITEMS"),
                 paste("IRREGULARLY","\n", "DISTRIBUTED","\n", "ITEMS"))

theta.label <- c("Normal",
                 "Bimodal",
                 "Skewed",
                 "Uniform")   

point.set <- c(21,22,23)

# Outer cycles for rotate through plots in 4 by 2 frame 

for (thetas in 1:4) {      # switch between distributions
  
  for (betas in 1:2) {     # switch between even grid and uniform grid
    
    # start the plot as empty
    
    options(warn=-1) # suppress warning of empty plot
    
    plot("n",
         main="",
         xlab="", ylab="",
         xlim=c(1,20),
         ylim=c(-0.25,+0.25),
         xaxp=c(1,20,19),
         yaxp=c(-0.25,+0.25,4),
         las=1); 
    
    options(warn=0) # restore warnings for debugging
    
    # select legends appearnce for top diagrams
    
    if (thetas == 1) {
      
      if (betas == 1) {
        
        legend("bottomright",
               legend=c("Circle:   GGUM",
                        "Square: GHCM",
                        "Diamond: PARELLA"), 
               bty = "n",
               cex = 2)
        
      }
      
      legend("topright",
             legend=beta.label[betas], 
             xjust = 1,             
             bty = "n",
             cex = 2)
      
    }
    
    if (betas == 1) {legend("topleft",
                            legend=paste(theta.label[thetas],
                                         "\n","Person",
                                         "\n","Distribution",
                                         sep=""), 
                            bty = "n",
                            cex = 2)}
    
    if (betas == 2 & thetas == 1) {text(10.5,-0.125,
                                        paste("Median and CI90% of\n",
                                              "difference between recovered\n",
                                              "and simulated probabilities"), 
                                        cex = 2)}
    
    
    abline(h=seq(-0.25,+0.25,length.out=9),v=1:20,
           lty=3,col="grey")
    
    abline(h=0,lty=2,col="black")
    
    
    # start inner cycle to rotate through models and items
    
    for (models in 1:3) {    # switch between models
      
      for (items in 1:20) {   # switch between items estimates
        
        # Arrows to provide empirical CI90 5%, 95%
        
        Lower.Bound <- Item.Quant05.delta.p.Vector.japm[[items]][betas,thetas,models]
        
        Upper.Bound <- Item.Quant95.delta.p.Vector.japm[[items]][betas,thetas,models]
        
        arrows(x0 = items,
               y0 = Lower.Bound,
               y1 = Upper.Bound,
               length = 0.05,
               angle = 90,
               code = 3,
               col = box.set1[models])
        
        # points will upload from list of arrays    
        
        points(x = items,
               y = Item.Median.delta.p.Vector.japm[[items]][betas,thetas,models],
               cex = 2.25,
               pch = point.set[models],
               bg  = color.set[models])
        
      } # end item cycle 
      
    }  # end models cycle
    
  }    # end plot colum cycle
  
}      # end plot row cycle

dev.off()