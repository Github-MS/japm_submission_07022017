#########################################################################
#                                                                       #
# Subject: Generation Data Sets Experiment JAPM                         #
# 800 sets, 100 replications for run, 8 runs                            #
# Calls function simulation.bin in .R file "simulation japm 07022017.R" #
#                                                                       #
#########################################################################

# Check on suitable mixture combination for mu = 0, sd = 1 experiment ------------

par(mfrow=c(5,5), mai = c(0.25,0.25,0.5,0.25))
mus    <- seq(0.1,0.9,0.1)
sigmas <- sqrt(1-(mus^2))
size   <- 1000
mixp   <- seq(0.5,0.9,0.1)

for (i in 1:length(mixp)) {
  
  for (j in 1: length(mus)) {
    
    for (k in  1:length(sigmas)) {
      
      if (j==k) {
      
      new <- c(rnorm(1000*mixp[i],-mus[j],sigmas[k]),
               rnorm(1000*(1-mixp[i]),mus[j],sigmas[k]))
      
      new <- scale(new)
      
      print(paste("P: ", mixp[i],
                  "Mu: ", mus[j],
                  "SD: ", round(sigmas[k],3),
                  "Skewness: ", round(skewness(new),3)))
      
      plot(density(new),
           cex.main = 1.1,
           ylab="", xlab="",
           main=paste("P: ",mixp[i],
                      " - Mu: ",mus[j],
                      "- Sigma: ",round(sigmas[k],2),
                      sep="")); grid()

      }
      
    }
    
  }
  
}

# Baseline is the unaffected simulated data matrix
# e.g. items locations are evenly set
# ideal points have a normal distribution
# this is a B = 1, T = 1 setting in the experimental design

# T = 2 represents a Symmetrical Mixture of Normal distributions for the ideal points

# T = 3 represents an asymmetrical Chi-square distribution

# T = 4 represents a Uniform distribution

# B = 2 represents an Uniform distribution for the items

# Constant parameters

# Data Matrix: 20 items x 1000 subjects
# range = c(-3,+3)
# subjects = 1000
# item = 20
# mu = rep(1,20)
# tau = "SSLM"

# Generate mixtures using vector of mixing proportion [1], mean[2] --------

Mixture <- function(n, mixing) { 

Mixt <- c(rnorm(n*mixing[1],-mixing[2], mixing[3]),
          rnorm((n-(n*mixing[1])),mixing[2], mixing[3])) # guarantes absence of rounding down # of subjects

return(Mixt)  
  
}

# aid to standardize mixtures
# calculate expected mean, sd of mixture distributions to support
# simulation and standardization

mixt.moment.calculator <- function(means, sds, proportions) {
  
  # means is vector of means
  # sds is vectors of sds
  # proportions is vector of mixing proportions
  
  moments <- matrix(nrow=2,ncol=1)
  
  rownames(moments)<-c("Mean","SD")
  
  moments[1,1] <- sum(means*proportions) # mixture mean
  
  moments[2,1] <- (sum(proportions*((means^2)+(sds^2)))-(moments[1,1]^2))^0.5 # mixture sd

  return(moments)
  
}


# The data set generation

# Simulation with mu = 0, sd = 1 for Theta --------------------------------------

generator.distribution.japm <- function(replications) {
  
  # Constant parameters
  
  its <- 20
  subs <- 1000
  item.range <- c(-2,+2)
  thresholds <- rep(1,20)
  reps <- replications
  
  sim.score <- NULL # storage for checks of effects
  
  sim.beta  <- NULL  # storage for simulation parameters beta
  
  sim.theta <- NULL  # storage for simulation parameters theta
  
  # set reference tem and subject distribution
  
  ###########################################################################
  
  # initialize randomization for beta, theta vectors
  
  set.seed(26041967)
  
  regular <- seq(-2, +2, length.out = 20) # get even spaced items
  
  # get uniform item distribution centred on mean = 0
  
  irregular <- sort(runif(20, -2, +2)) 
  
  irregular <- irregular - mean(irregular)
  
  Beta.Set  <- list(regular,irregular) # beta sequence 
  
  # add fixed set of theta vectors for the three cases: SN, bimodal symmetric mixture, skewed mixture
  
  set.seed(05051945) # randomize for theta vector standard normal
  
  normal <- as.numeric(scale(rnorm(1000))) # centred and rescaled random draw to SN(0,1)
  
  set.seed(04041918) # randomize for theta vector simmetric mixture
  
  # Mixture with N(-0.99,sqrt(0.0975)), N(+0.95,sqrt(0.0975)) with equal proportions: rescaled to met theory values
  # mean = 0, sd = 1 as in SN(0,1) first scenario
  
  # drawn from "http://stackoverflow.com/questions/18919091/generate-random-numbers-with-fixed-mean-and-sd"
  
  bimodal <- as.numeric(scale(c(rnorm(500,-0.99,sqrt(1-(0.99^2))),
                                rnorm(500,+0.99,sqrt(1-(0.99^2))))))
  
  set.seed(08051945) # randomize for theta vector skewed mixture
  
  # Chi square with df = 8 that is close in shape to Mixture with N(-sqrt(3),1), N(sqrt(3),1)
  # with p1 = 0.9 and p2 = 0.1 as in the previous : 
  # rescaled to met theory values mean = 0, sd = 1 as in N(0,1) first scenario
  
  skewed <- as.numeric(scale(rchisq(1000,8)))
  
  # the mixture is close in characteristics to X-2 df = 6, but have wider dispersion guaranteeing coverage

  set.seed(05051945) # randomize for theta vector standard normal
  
  # centred and rescaled random draw from U(-2.25,+2.25)  
    
  uniform <- as.numeric(scale(runif(1000,-2.25,+2.25))) 
  
  
  Theta.Set <- list(normal,bimodal,skewed,uniform)
  
  ###########################################################################  
  
  # matrix of probabilities is drawn for each simulation of scenarios
  # then replications are run for each transformation into binaries
  
  # Beta distribution loop
  
  for (items in 1:2) {  
    
    # Theta distribution loop
    
    for (subjects in 1:4) { 
      
      # Loop through replications
      
      for (replicates in 1:reps) {
        
        set.seed(1000 + replicates + items*10 + subjects) # set seed to ensure consistency and have a reproducible set of different binary randomizations in each replication                
        
        data <- simulator.bin(item.range,
                              subs,
                              its,
                              thresholds,
                              Beta.Set[[items]],       # Switch from fixed regular spaced to irregular spaced 
                              Theta.Set[[subjects]],   # Switch from SN, to mixed symmetric, to mixed skewed, to uniform
                              thresholds)
        
        # set addresses for export files        
        
        GGUM.address <- paste("P:/Work/PhD/Project_1/JAPM1/SIMULATION/GGUM/EXP2_",
                              items,"_",subjects,"_",replicates,
                              ".DAT",sep="") # set the filename to reflect the levels
        
        PARELLA.address <- paste("P:/Work/PhD/Project_1/JAPM1/SIMULATION/PARELLA/E2_",
                                 items,subjects,replicates,
                                 ".PAR",sep="") # set the filename to reflect the levels
        
        RUMMFOLD.address <- paste("P:/Work/PhD/Project_1/JAPM1/SIMULATION/RUMMFOLD/E2_",
                                  items,subjects,replicates,
                                  ".DAT",sep="") # set the filename to reflect the levels
        
        # collect simulation data for later analysis
        
        level = (items*10)+subjects
        
        sim.score <- rbind(sim.score,
                           c(replicates,level,colSums(data$Scores)))
        
        sim.beta  <- rbind(sim.beta,
                           c(replicates,items,subjects,as.vector(data$Parameters$Items))) # collect items locations
        
        sim.theta <- rbind(sim.theta,
                           c(replicates,items,subjects,as.vector(data$Parameters$Subjects))) # collect subjects locations
        
        # reformat the data for GGUM, PARELLA compatibility
        
        ggum.table <- parella.table <- rummfold.table <- mudfold.table <- data$Scores
        
        # Set row names into a string with 4 character, blanks preceeding the actual digit characters
        
        rownames(ggum.table) <- apply(as.matrix(1:dim(ggum.table)[1],nrow=dim(ggum.table)[1]),
                                      1,
                                      function(x) paste(substr("   ",1,3-floor(log10(x))),x," ",sep="")) # add leading and trailing blanks 
        
        rownames(rummfold.table) <- apply(as.matrix(1:dim(rummfold.table)[1],nrow=dim(rummfold.table)[1]),
                                          1,
                                          function(x) paste(substr("000",1,3-floor(log10(x))),x," ",sep="")) # add leading and trailing blanks 
        
        # adding files specs to data for use in Mudfold
        
        # output file with no col headings
        
        write.table(ggum.table,
                    GGUM.address,
                    quote=FALSE,
                    sep="",
                    col.names=FALSE)
        
        write.table(parella.table,
                    PARELLA.address,
                    quote=FALSE,
                    sep="",
                    row.names = FALSE,
                    col.names = FALSE)
        
        write.table(rummfold.table,
                    RUMMFOLD.address,
                    quote=FALSE,
                    sep="",
                    col.names = FALSE)  
        
      } # close k loop - vary Beta level 
      
    } # close j loop - vary Theta level
    
  } # close i loop - randomization
  
  check <- list(Scores=sim.score,Betas=sim.beta,Thetas=sim.theta) # collect simulation parameters
  
  return(check)
  
  remove(data) # clear out memory
  
}

# Generation of Data with mu = 0, sd = 1 ------------------------------------------

replicates <- 100

japm.distribution <- generator.distribution.japm(replicates)

check.count <- NULL

check.beta <- NULL

check.theta <- NULL

for (l in 1:8) {
  
  check.count <- rbind(check.count,
                       colMeans(japm.distribution$Scores[japm.distribution$Score[,2]==c(11,12,13,14,21,22,23,24)[l],]))
  
}

for (m in 1:2) {
  
  check.beta <- rbind(check.beta,
                      colMeans(japm.distribution$Betas[japm.distribution$Betas[,2]==c(1,2)[m],]))
}

for (o in 1:4) {
  
  check.theta <- rbind(check.theta,
                       mean(japm.distribution$Thetas[japm.distribution$Thetas[,3]==c(1,2,3,4)[o],4:1003]))
}

check.count  <- as.data.frame(round(check.count))

check.beta  <- as.data.frame(round(check.beta,2))

check.theta  <- as.data.frame(round(check.theta,2))

View(check.count)

View(check.beta)

View(check.theta)