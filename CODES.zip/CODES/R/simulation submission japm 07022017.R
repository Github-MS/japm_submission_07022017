# First Created:  19/03/2015

# Content:  Simulation functions for binary and graded preference data
# for PhD project on Generalized Squared Distance Logistic Model for unimodal
# (single peaked) probability preference function.

# Purpose:  Generate datasets based on GSDLM specification to assess performance 
# of older methods.

# interpoint enables recovery of all distances either between items, between each ideal points or
# between items and ideal points, to be used for checks and graphs. return a nxp matrix. Used in [constrain]

interpoint<-function(set1,set2) {  
  
  set1<-as.matrix(set1,length(set1),1) # set vector as matrix for use in apply
  
  delta<-apply(set1,1,function(x) (x-set2)) # returns matrix distances between each items and all ideal points
  
  delta
  
}

# heaps generates # of subjects to which assign normal distribution of ideal points to simulate DIF/ cluster situations
# [used in mixer]

heaps<-function(subject,item) {
  
  if (item>2) item <- item else item <- item + 1 # ensure that at least two values can be chosen from with sample
  
  k <- sample(2:item,1) # select random # of clusters
  
  split <- rpois(k,subject/k) # share out subjects across clusters at random
  
  mixer <- round(subject*split/sum(split)) # standardize on the value of subjects
  
  delta <- sum(mixer)-subject         # check discrepancy between subjects and total subjects across clusters
  
  place <- sample(1:length(mixer),1)  # select a cluster to which add/subtract shortcoming/excess subjects
  
  mixer[place] <-  mixer[place]-delta # enforce total sum equal to stipulated subjects
  
  mixer
  
}

# mixer generate theta values around clusters [used in simulator.1]

mixer <- function(range,sd,subjects,items) {
  
  clusters <- heaps(subject = subjects,
                    item = items) # get size of clusters
  
  set <- NULL # Prepare vector of clustered values
  
  # the sd of each cluster is proportional to the square root of 'mass' of the clusters
  # as it splits the variance accordingly.
  
  clusters.sd<-(((sd*1.5)^2)*(clusters/sum(clusters)))^0.5
  
  for (i in 1:length(clusters)) { # stack sets of random normal values for each cluster into a single vector 
    
    set<-c(set,rnorm(clusters[i],
                     runif(1,range[1],range[2]),
                     clusters.sd[i]))
  }
  
  
  set
  
}

# constrain calculates tau values dependent on position [used in simulator.bin]

constrain<-function(beta) {
  
  max.tau<-apply(abs(interpoint(beta,beta)),1,function(x) 1/max(x)) # set maximum values of random addition to tau = 1
  
  max.tau<-as.matrix(max.tau,col=1) # change format for use in apply()
  
  tau<-rep(1,length(beta))+as.vector(apply(max.tau,1,
                                           function(x) rnorm(1,0,x))) # vector of default tau values for each item
  
  # checklist<-list(mu,beta,theta,mu.trimmed,max.delta,max.tau,tau)
  
  tau
  
}

# Support random allocation of missing values by returning a
# matrix with row and col reference in 1st, 2nd column
# the reference is used to set matrix cell to NA

randrowcol <- function(x,item) {
  
  rand.row  <- ceiling(x/item) # use ceiling to detemine row position
  
  rand.col  <- (x%%item==0)*item+x%%item  # use modulus to get col position and set 0 value to match item value
  
  reference <- cbind(rand.row,rand.col)
  
}

# simulator.bin define a scenario with a unidimensional latent variable, with range [-4,4] and with
# subjects endorsing items with a binary variable 0,1. The output is a NxP matrix of N subjects
# and P items. The simulator will offer several precanned options for the parameter specification
# plus manual ones.

# SIMULATOR FUNCTION ------------------------------------------------------

simulator.bin<-function(range=c(-4,4),
                        subjects=100,
                        items=10,
                        mu=c("SSLM","uniform","p95"),
                        beta=c("even","uniform","normal","thick"),
                        theta=c("RE","normal","uniform","binary","ordered","multinomial","mixture"),
                        tau=c("SSLM","constrained"),
                        missing=NULL) {
  

  # declare variables for generation of binary endorsement data (1,0) and filter out GIGO data
  
  # range:    bounds for latent variable dimension. Default value = [-4,4]
  # subjects: # of subjects selecting items. Default value = 100
  # items:    # of items used in the simulation. Default Value = 10
  
  if (is.numeric(range)!=TRUE | length(range)!=2) stop("The range parameter does not match the specs") 
  
  if (is.numeric(subjects)!=TRUE | length(subjects)!=1 | subjects<2) stop("The subjects parameter does not match the specs")
  
  if (is.numeric(items)!=TRUE | length(items)!=1 | items<2 | items>subjects ) stop("The items parameter does not match the specs")
  
  interval <- (range[2]-range[1])/(items+1) # set a variable for the average inter-item distance
  
  midpoint <- median(range) # used for random generation according to N() for beta, theta
  
  range.sd <- abs(range[2]-midpoint)/qnorm(0.995) # used for random generatiom according to N() for beta, theta
                                                  # to obtain 99% of random values within range  
                                                  # for theta sd is 'stretched' out by adding 10% of its value
  ###################
  
  # flag: error trap variable to screen out bad specs
  
  flag <- NULL
  
  ###################
  
  # mu: This is a vector of mu_j, threshold parameter for endorsement for each jth item.
  #     We can use a manual input with a given set of value (for simulation driven by
  #     specific distributional settings) or by pre-set values.
  
  # uniform:  (Default) The mu_j  are thresholds in the sense that these are standardized squared distance 
  #           inversion points for the probability to switch between less  than 0.5 to more than 0.5.
  #           Thus high values raise the chance of p=0.5 for any given squared distance.  Also, we
  #           must impose mu_j>0. We then set the mu_j such that in case item i and ideal point j overlap 
  #           precisely (0 squared distance) we have a 95% probability to endorse the item. 
  #           It can be shown that then we must have  mu_j=ln(19). We choose this result as an upper 
  #           bound "familiar" stochastic threshold for the "acceptance/rejection" of the hypothesis 
  #           that any given subject endorses an item. Then we let mu_j take any value on the interval
  #           [0,ln(19)].
  
  # p95:      This implies a ln(19)(px1) vector, p being the # of items, as it holds the threshold to be
  #           constant across items and ln(19)in value. The formulation implies that if any individual
  #           ideal point is spot on an item location, then the subject has 95% chance to endorse the item
  
  # SSLM:     This implies a 0(px1) vector, p being the # of items, as it holds the latitude to be
  #           constant across items. The formulation - at least for a binary case - then
  #           matches the SSLM spec.
  
  #  defer to pre-sets values if a vector is not given, and stops if an incorrect vector length is given
  
  if (is.numeric(mu)==TRUE) {
    
    # validate length and type of values of mu 
    
    if (length(mu)!=items|any(mu<0)) stop("The threshold vector length does not match the specs") else mu=mu } else { 
      
      # screen out mispellings or wrong choice for labels
      
      flag <- (is.character(mu)==TRUE & length(mu)>1)|(is.character(mu)==TRUE & length(mu)==1 & any(is.na(match(mu,c("uniform","p95","SSLM"))))==FALSE)
      
      if (flag) {choice=match.arg(mu) 
                 
                 mu<-switch(choice,
                            SSLM=rep(0,items),
                            uniform=runif(items,0,log(19)), 
                            p95=rep(log(19),items)) } else stop(paste(mu,"is not a recognized option"))} # stop mispelled option}s
  
  
  
  ###################
  
  # beta: This is a vector of beta_j, location parameter of the jth item on latent variable dimension 
  
  # even: Regular intervals set by items, plus a random jitter ~ U(). Validated questionnaire scenario.
  #       the sequence of item location is designed to be enclosed by the LV bounds.
  
  # uniform: "chaotic" scenario with item representing unplanned stimuli. 
  
  # normal: scenario where item follow a normal distribution centred on the middle of the continuum
  #         and a sd derived as the ratio of the half the length of the range divided by the SN quantile
  #         that yields 2*p(quantile)=0.01, e.g. 99% of values would fall within the range.
  
  # thick:  extreme distribution with greater share of mass in the tails [to be discussed]
  
  if (is.numeric(beta)==TRUE) {
    
    # validate length of beta is correct
    
    if (length(beta)!=items) stop("The item vector length does not match the specs") else beta=beta } else { 
      
      # screen out mispellings or wrong choice for labels
      
      flag <- (is.character(beta)==TRUE & length(beta)>1)|(is.character(beta)==TRUE & length(beta)==1 & any(is.na(match(beta,c("even","uniform","normal"))))==FALSE)
      
      if (flag) {choice=match.arg(beta) 
                 
                 beta<-switch(choice,
                              even    = seq(range[1]+interval,range[2]-interval,by=interval)+runif(items,-interval/items,interval/items),
                              uniform = sort(runif(items,range[1],range[2])), 
                              normal  = sort(rnorm(items, midpoint, range.sd)))} else stop(paste(beta,"is not a recognized option"))} # stop mispelled options
  ###################
  
  # theta: This is a vector of theta_i, location parameter of the ith person on the latent variable dimension (ideal point)
  
  
  # RE:       Default setting. Random effect scenario, with mean 0 and sigma determined by the range as in beta and inflated by 50%
  #           to enable lower and upper bound coverage of the most extreme items.
  
  # normal:   Default scenario in which the subjects are sorted on the LV with a N() distribution with a mean
  #           as N() random value on the continuum. The sd for both N() distributions are the same of the RE case (inflated) 
  
  # uniform:  Subjects can be located anywhere on the LV continuum with equal probability, with strected out range by 50%.
  
  # binary, ordered, multinomial: to be developed. DIF scenarios based ona binary factor (like gender), an ordered factor(like age), a multinomial factor (SES)
  
  # mixture:  Cluster scenario where subjects are grouped togetjer on the continuum. 
  #           We set it as a mixture of k clusters with N(theta,sigma) and n subjects randomly distributed across them
  #           The number of subjects allocated to each mixture element is Pois(lambda), setting lambda=f(#subjects/k).
  #           The k is selected at random on the range 2:#items. See function mixer.
  #           The theta, sigma are set from runif(1,range) and runif(1,0,average interval).
  
  if (is.numeric(theta)==TRUE) {
    
    # validate length of theta is correct
    
    if (length(theta)!=subjects) stop("The persons vector length does not match the specs") else theta=theta } else {
      
      # screen out mispellings or wrong choice for labels
      
      flag <- (is.character(theta)==TRUE & length(theta)>1)|(is.character(theta)==TRUE & length(theta)==1 & any(is.na(match(theta,
                                                                                                                      c("RE",
                                                                                                                        "normal",
                                                                                                                        "uniform",
                                                                                                                        "binomial",
                                                                                                                        "ordered",
                                                                                                                        "multinomial",
                                                                                                                        "mixture"))))==FALSE) 
      if (flag) { choice=match.arg(theta)
                  
                  theta<-switch(choice,
                                RE      = rnorm(subjects, 0, 1.1*range.sd),
                                normal  = rnorm(subjects,rnorm(1,midpoint,range.sd),1.1*range.sd),  # set SN 'hyperprior' on theta distribution mean value
                                uniform = runif(subjects,1.1*range[1],1.1*range[2]), 
                                mixture = mixer(range,(1.1*range.sd),subjects,items))} else stop(paste(theta,"is not a recognized option"))} # stop mispelled options
  
  ###################
  
  # tau:      This is a vector of tau_j, latitude of acceptance for each jth item
  
  # SSLM:     (Default): it implies a 1(px1) vector, p being the # of items, as it holds the latitude to be
  #           constant across items. The formulation - at least for a binary case - then
  #           matches the SSLM spec. To enforce a T SSLM mu must also be set as SSLM
  
  # constrained: We treat τ_j as a measure of rhetorical device that 'attracts' endorsements beyond the simple
  #              linear distance. This factor is constrained by the location of the item, following Sherif and Hovland (1961)
  # on the latitude of acceptance of people. They noted that a subject with extreme  views on either side of the continuum has reduced
  # tolerance for neighbouring items compared to subjects with views (location) closer to the centre. 
  
  # To describe this situation, we set τ_j with a constant value of 1 plus a random component following an half-normal distribution,
  # with mean 0 and standard deviation equal to the inverse of the maximum pairwise distance between an item j and the remaining items.
  # Thus, extreme items have reduced increase of the latitude parameter because they have a greater gap from the most distant items,
  # whereas items close to the centre may have greater latitude. By using the half-normal distribution we guarantee that small
  # increases close to 0 are anyway more likely than greater increases.      
  
  # However we do not necessarily constrain τ_j to be greater than 1in vector settings. it si accepted that this parameter can be smaller
  # than 1 - albeit strictly positive to match, for example, PARELLA model patterns.
  
  # we set tau to SSLM by default, 
  
  if (is.numeric(tau)==TRUE) {
    
    # validate length and values of tau and assign vector value
    
    if (length(tau)!=items|any(tau<=0)) stop("The latitude vector length does not match the specs") else tau=tau} else {
      
      # screen out mispellings or wrong choice for labels
      
      flag <- (is.character(tau)==TRUE & length(tau)>1)|(is.character(tau)==TRUE & length(tau)==1 & any(is.na(match(tau,c("constrained","SSLM"))))==FALSE)
      
      if (flag) { choice=match.arg(tau) # use options
                  
                  tau<-switch(choice,
                              SSLM=rep(1,items),            
                              constrained=constrain(beta)) } else stop(paste(tau,"is not a recognized option"))} # stop mispelled options
  
  ###################
  
  remove(flag) # cleanup error trap variable for use in loops
  
  ###################
  
  # use matrix operations
  # build nxp matrices for the 4 parameters
  
  threshold<-rep(1,subjects)%o%mu # build nxp matrix with columns of mu values
  
  item<-rep(1,subjects)%o%beta # build nxp matrix with columns of beta values
  
  latitude<-rep(1,subjects)%o%tau # build nxp matrix with columns of tau values
  
  ideal<- theta%o%rep(1,items) # build nxp matrix with rows of theta values
  
  delta<-interpoint(beta,theta) # QC check
  
  # probability matrix according to GSDLM specs
  
  matrix.p <- exp(threshold-(((ideal-item)/latitude)^2))/(1+exp(threshold-(((ideal-item)/latitude)^2)))
  
  # Select items using a Bernoulli stochastic process
  # where the calculated probability determine the chance of endorsement
  # specs below reflect the the (Bernoulli Uniform) described in Kachitvichyanukul, V.
  # and Schmeiser, B. W. (1988), 
  # "Binomial random variate generation, Communications of the ACM 31", 216-222.
  # This approach is marginally faster (approx 1/1000000 sec per simulation) than the 
  # the BTPE algorithm described in the same paper and applied to the function rbinom(n,1,p). 
  # For this reason and clarity of exposition we use the former.
  
  score <- apply(matrix.p, 2, function (x) (runif(length(x)) <= x) * 1) # feed columns of matrix to return bernoulli values matrix as final output
  
  # Select random MCAR fraction of outcomes to be set as missing.
  
  if (is.null(missing)) score=score else {
    
    # validate missing parameter and generate mssing values accordingly  
    
    if (is.numeric(missing)!=TRUE | length(missing) !=1) stop("The missing parameter does not match the specs") else {
      
      # generate sequence of positions in matrix to be converted in missing values  
      
      NA.set <- sample(1:(subjects*items),
                       as.integer(round(subjects*items*missing)))
      
      # coordinates<-randrowcol(NA.set,items) # return RC reference for cell matrix to be set as NA
      
      score.vector<-as.vector(score) # turn matrix into vector
      
      score.vector[NA.set]<-NA # assign the position of NA.set to NA vaues
      
      score<-matrix(score.vector,nrow=subjects,ncol=items) # reset score as matrix with NA values included
      
    }
    
  }
  
  
  # store output in list for QA
  
  parameters<-list(Parameters=list(Thresholds=mu,Items=beta,Latitudes=tau,Subjects=theta),
                   Range.Data=c(interval,range.sd),Mu=threshold,Beta=item,
                   Tau=latitude,Theta=ideal,Delta=delta,
                   Probs=matrix.p,Scores=score) 
  
  # options(warn=0) # restore warnings
  
  # print(Sys.time()-Now)
  
}

# display is a Graphic function to display the simulation results.
# Items are marked as diamonds, persons as dots, tau values are set as vertical bars centred on items, 
# IRFs probability curves are displayed for each item with lowess smoother.

# the output is a matrix of diagrams

# Thresholds=mu,Items=beta,Latitudes=tau,Subjects=theta)

display <- function(x) {
  
  options(warn=-1) # suppress spurious warnings
  
  # x is the simulation object generated by simulation.bin
  
  set <- x$Parameters # collect parameters from simulation output, placed in a list as fist element of the output object (a list)
  
  set.probs <-x$Probs # collect probabilities from simulation output, placed in a list as eight element of the output object (a list)
  
  set.items <- length(set$Items)
  
  set.persons <- length(set$Subjects)
  
  set.item.colors <- rainbow(n=set.items) # set varying colours
  
  set.person.colors <- rainbow(n=set.persons)
  
  set.beta <-cbind(sort(set$Items),rep(0,set.items)) # set data to display points on x-axis - data sorted to ensure colour ordering
  
  beta.order <- order(set$Items) # to be used to sort IRFs / Scores
  
  set.theta <- cbind(sort(set$Subjects),rep(0,set.persons)) 
  
  set.tau  <- cbind(sort(set$Items-set$Latitudes), # set data to display boundaries of latitude of acceptance
                    sort(set$Items+set$Latitudes), 
                    rep(0,set.items))
  
  set.range <- c(floor(min(set.tau[,1],set$Items,set$Subjects)),
                 ceiling(max(set.tau[,2],set$Items,set$Subjects))) # draws the x-axis extreme values taking into account all display points
  
  # set the graph output window
  
  #  png("plot1.png",
  #      width = 900, height = 600)
  
  par(mfrow=c(2,2))
  
  # item display
  
  # mark latitude boundaries first to adjust x axis range by default
  
  plot(set.tau[,c(1,3)], 
       xlab="Latent Variable",
       xlim=set.range, 
       main="Items Plot",
       pch=124, col=set.item.colors,
       bty="n",
       ylim=c(-0.1,1), yaxt="n", ylab="")
  
  points(set.tau[,c(2,3)], 
         pch=124, col=set.item.colors,
         bty="n")
  
  # add item points, color varying from left to right, red to violet
  
  points(set.beta, 
         pch=23, col="black", bg=set.item.colors,
         bty="n")
  
  abline(v=seq(set.range[1],set.range[2],by=1), h=0,lty=3,col="grey") # mark 0 and x-axis grid
  
  # persons display
  
  plot(set.theta, 
       xlab="Latent Variable",
       xlim=set.range, 
       main="Persons Plot",
       pch=20, col=set.person.colors,
       bty="n",
       ylim=c(-0.1,1), yaxt="n", ylab="")
  
  lines(density(set.theta[,1]))
  
  abline(v=seq(set.range[1],set.range[2],by=1), h=0,lty=3,col="grey") # mark 0 and x-axis grid
  
  # IRF display
  
  plot("n", 
       xlab="Latent Variable",
       xlim=set.range, 
       main="IRFs",
       bty="n",
       yaxp=c(0,1,10), ylim=c(0,1), ylab="Probability of Selection")
  
  theta.order <- order(set$Subjects) # get ordering of persons locations
  
  for (i in 1:set.items) { # cycling though items generate IRFs using calculate probabilities of endorsement for each item
    
    set.irf <- cbind(set.theta[,1],set.probs[theta.order,beta.order[i]])
    
    lines(set.irf,col=set.item.colors[i])
    
  }
  
  grid()
  
  # fine tune grid values
  
  abline(v=seq(set.range[1],set.range[2],by=1),
         h=c(0.1,0.3,0.5,0.7,0.9),col="lightgrey",lty="dotted")
  
  # item scoring display (column marginals)
  
  colmargin <- colSums(x$Scores[,beta.order],na.rm = T) # force calculation in presence of missing values
  
  # modify xlab text in presence of missing values
  
  if (sum(is.na(x$Scores))>0) missing.string <- "Missing Observations in Grey" else missing.string <- "No missing values"
  
  barplot(colmargin,
          main="Marginal Items Columns Counts",
          xlab=paste("Items \n ",missing.string), 
          ylab=paste("Endorsements"),
          names.arg=1:set.items,
          col=set.item.colors)
  
  # overlay shaded grey bars of frequency of missing values
  
  if (sum(is.na(x$Scores))!=0) {
    
    col.na<-colSums(is.na(x$Scores))
    
    barplot(col.na,
            col="grey60",
            border=NA,
            density=rep(85,set.items),
            add=T)
    
  }
  
  grid(nx=NA,ny=NULL)
  
  # dev.off()
  
  options(warn=0) # restore warnings
  
  par(mfrow=c(1,1)) # reset display window
  
}